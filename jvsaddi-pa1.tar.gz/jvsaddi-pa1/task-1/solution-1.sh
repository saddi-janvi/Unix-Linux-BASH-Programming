#!/bin/bash

mkdir -p Assignment-1

# Loop through numbers from 1 to 10 
for i in {1..10}
do
    mkdir -p Assignment-1/Query-$i
    
    # Create the response file inside the Query directory
    touch Assignment-1/Query-$i/response-$i.sh
done

