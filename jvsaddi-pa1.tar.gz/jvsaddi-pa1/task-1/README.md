# Readme for Task-1

## How to test your solution?

Use the following command

    $ make test

It should print **only** "Passed" if your script passes the test; otherwise it
prints the difference with the expected output.


## Clean command

    $ make clean
