#!/bin/bash

# Redirect the output to cpuinfo.txt
> cpuinfo.txt

# Get the total number of processors
total_processors=$(grep -c '^processor' /proc/cpuinfo)
echo "$total_processors" >> cpuinfo.txt

# Get core id of each processor
core_ids=$(grep -o 'core id\s*:\s*[0-9]*' /proc/cpuinfo | awk -F':' '{print $2}' | tr -d ' ')
echo "$core_ids" >> cpuinfo.txt

# Get cache size available to each processor
cache_sizes=$(grep -o 'cache size\s*:\s*[0-9]*[ ]*[A-Za-z]*' /proc/cpuinfo | awk -F':' '{print $2}' | tr -d ' ')
echo "$cache_sizes" >> cpuinfo.txt


