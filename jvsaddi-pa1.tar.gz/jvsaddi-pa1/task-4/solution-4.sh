#!/bin/bash


ps -ef -u $(whoami) | grep -e 'infloop' | awk '{print $2}' | xargs -I {} kill -9 {}

