#!/bin/bash

# Check if a URL argument is provided
if [ $# -ne 1 ]; then
  echo "Usage: $0 <URL>"
  exit 1
fi

for file in sample_data/*; do
  if [ -f "$file" ]; then
    smart_count=$(grep -o -i "smart" "$file" | wc -l)
    os_count=$(grep -o -i "operating system" "$file" | wc -l)
    
    echo "$file smart $smart_count" >> result.txt
    echo "$file operating system $os_count" >> result.txt
  fi
done

mkdir -p smart
mkdir -p OS

for file in sample_data/*; do
  if [ -f "$file" ]; then
    if grep -qi "smart" "$file"; then
      cp "$file" smart/
    fi
    if grep -qi "operating system" "$file"; then
      cp "$file" OS/
    fi
  fi
done
