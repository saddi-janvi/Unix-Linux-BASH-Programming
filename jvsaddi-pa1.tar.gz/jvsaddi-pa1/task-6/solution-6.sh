#!/bin/bash

# Extract the input.tar.gz archive
tar -xzvf input.tar.gz

# Create directories for TXT, JPG, and ZIP
mkdir -p TXT JPG ZIP

# Move .txt files to TXT directory
find input/ -type f -name "*.txt" -exec mv {} TXT/ \;

# Move .jpg files to JPG directory
find input/ -type f -name "*.jpg" -exec mv {} JPG/ \;

# Move the rest of the files to ZIP directory
find input/ -type f -exec mv {} ZIP/ \;

# Compress and archive the ZIP directory
tar -czvf rest_zipped.tar.gz ZIP

# Check if the archive file was created successfully
if [ $? -eq 0 ]; then
  echo "Archive 'rest_zipped.tar.gz' created successfully."
else
  echo "Failed to create archive."
fi

