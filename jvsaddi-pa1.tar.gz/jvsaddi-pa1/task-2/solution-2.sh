#!/bin/bash

# Find all files with the .c extension in the current directory
find . -type f -name "*.c" -print0 | xargs -0 tar -cvf allcfiles.tar --transform='s#.*/##'
